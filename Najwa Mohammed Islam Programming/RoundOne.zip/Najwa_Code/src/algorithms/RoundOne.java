package algorithms;

public class RoundOne {
	
	public static void bubbleSort(int[] arr){

		int n = arr.length;
		boolean swapped = false;
		System.out.print("====== Bubble Sort ======\n");
		// Display the UnSorted Array
		System.out.print("\n UnSorted Array \n ");
		for (int number : arr) {
			System.out.print(number+"  ") ;
		}
		for (int i=0; i<n-1; i++) {
			for(int j=0; j<n-i-1; j++) {
				if(arr[j]>arr[j+1]) {
					//swap array[j] and array[j+1]
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
					swapped = true;
				}
			} 
			// If no two elements were swapped by the inner loop, then break
			if(!swapped) {
				break;
			}
		}
		// Display the Sorted Array
		System.out.print("\n Sorted Array \n ");
		for (int number : arr) {
			System.out.print(number+"  ");
		}	
		System.out.print('\n');
	}
	
	public static void selectionSort(int[] array){
		
        int n = array.length;
        System.out.print("\n====== SelectionSort ======\n");
        // Display the UnSorted Array
		System.out.println("\n UnSorted Array ");
		for (int number : array) {
			System.out.print(number+"  ");
		}
		for (int i=0; i<n-1; i++) {
			int min = i;
			for (int j=i+1; j<n; j++) {
				if (array[j] < array[min])
				min = j;
			}
			//swap array[minimum] and array[i]
			int temp = array[min];
			array[min] = array[i];
			array[i] = temp;
		}
		// Display the Sorted Array
		System.out.println("\n Sorted Array ");
		for (int number : array) {
			System.out.print(number+"  ");
		}
		// Display the Highest  Score
		System.out.println("\n Highest  Score is "+(array[7]));

	}
	
	public static void linearSaerch(int[] arr, int x){
		
		System.out.print("\n====== LinearSaerch ======\n");
		System.out.print('\n');
		    // the size of the array 
			int n = arr.length;
			
			boolean exist = false;
			
			for(int i=0; i<n; i++) {
				if(arr[i]==x) {
					// if the Score exist print exist
					System.out.println("Exist");
					exist = true;
				}
			}
			// In case the Score not exist print not exist
			if (!exist) {
				System.out.println("\n Not Exist");
			}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] studentsID = {107,105,103,106,108,102,104,101};
		bubbleSort(studentsID);
        
		int [] studentsScore = {85,92,78,66,90,76,88,72};
		selectionSort(studentsScore);
		
		int x = 92;
		linearSaerch(studentsScore, x);
	}

}
