package employeeMangementSystem;

public class MainMenu {
	public void menu()
	  {
	    System.out.println("\n===========================================");
	    System.out.println("========EMPLOYEE MANAGEMENT SYSTEM=========");
	    System.out.println("===========================================");
	    System.out.println("-------------------------------------------");
	    System.out.println("------------- NAJWA MOHAMMED --------------");
	    System.out.println("-------------------------------------------");
	    System.out.println("\n\nTo Add an Employee Details   : Press 1");
	    System.out.println("To See an Employee Details   : Press 2");
	    System.out.println("To Remove an Employee        : Press 3");
	    System.out.println("To Update Employee Details   : Press 4");
	    System.out.println("To Exit the EMS Portal       : Press 5");

	  }

}



