package employeeMangementSystem;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

import employeeMangementSystem.Employee_Detail;

public class Add_Employee {
	 public void createFile()
	    {
	        Scanner sc=new Scanner(System.in);

	        Employee_Detail emp=new Employee_Detail();
	        emp.getInfo();
	        try{
	            File f1=new File("file"+emp.Employ_ID+".txt");
	            if(f1.createNewFile()){
	                FileWriter myWriter = new FileWriter("file"+emp.Employ_ID+".txt");
	                myWriter.write("Employee ID                :"+emp.Employ_ID+"\n"+
	                "Employee Name              :"+emp.Name+"\n"+
	                "Last Name                  :"+emp.Last_Name+"\n"+
	                "Employee Contact           :"+emp.Employ_Contact+"\n"+
	                "Email Information          :"+emp.Email+"\n"+
	                "Employee position          :"+emp.Position+"\n"+
	                "Employee Salary            :"+emp.Employ_Salary);
	                myWriter.close();
	                System.out.println("\nEmployee has been Added Successfully\n");

	                System.out.print("\nPress Enter to Continue...");
	                sc.nextLine();
	            }
	            else {
	                System.out.println("\nEmployee already exists!");
	                System.out.print("\nPress Enter to Continue...");
	                sc.nextLine();
	            }
	        }
	        catch(Exception e){System.out.println(e);}
	    }

}
