package employeeMangementSystem;

import java.util.Scanner;

public class Employee_Detail {
	    String Name;
	    String Last_Name;
	    String Email;
	    String Position;
	    int Employ_ID;
	    int Employ_Salary;
	    int Employ_Contact;
	    public void getInfo()
	    {
	        Scanner sc=new Scanner(System.in);
	        System.out.print("\nEnter Employee  ID            -: ");
	        Employ_ID=sc.nextInt();
	        System.out.print("Enter Employee Name           -: ");
	        Name=sc.next();
	        System.out.print("Enter Employee Last Name      -: ");
	        Last_Name=sc.next();
	        System.out.print("Enter Employee Email          -: ");
	        Email=sc.next();
	        System.out.print("Enter Employee Position       -: ");
	        Position=sc.next();
	        System.out.print("Enter Employee contact Number -: ");
	        Employ_Contact=sc.nextInt();
	        System.out.print("Enter Employee Salary         -: ");
	        Employ_Salary=sc.nextInt();
	    }


}
